# -*- coding: utf-8 -*-
# Copyright 2022-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from . import booking_vehicle_details
from . import inspection_vehicle_details
from . import repair_vehicle_details
